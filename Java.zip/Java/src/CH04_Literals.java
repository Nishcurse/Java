import java.sql.SQLOutput;
import java.util.Scanner;
public class CH04_Literals {
    public static void main(String[] args) {
//        byte age = 19;
//        short noOfFamily = 455;
//        long mobileNo = 8719053045l;
//        char Grade = 'A';
//        float Percentage = 96.5f;
//        double Pie = 3.142564135;
//        boolean isMen = true;
//        String Sologan = "PKMKB";
//        double sum = (age+noOfFamily+mobileNo);
//        System.out.print(sum);
          Scanner sc = new Scanner(System.in);
//        System.out.println("Enter Your Name ?");
//        String name =sc.nextLine();
//        System.out.println("hello, " + name + " Nice to see you");
//        System.out.println("Enter the length you want to conver into miles ?(in km)" );
//        int a = sc.nextInt();
//        float b = a/1.609f;
//        System.out.println("It's " + b +" miles");
        System.out.println("enter your no.:");
        System.out.print(sc.hasNextLong());
    }
}
