public class Main {
//    Yeh Function hai inbuilt
    public static void main (String[] args) {
//        This is lecture 3
        System.out.print("The sum of these three number :");
        int num1 = 12;
        int num2 = 34;
        int num3 = 76;
        int sum = num1 + num2 + num3;
        System.out.print(sum);

    }
}

