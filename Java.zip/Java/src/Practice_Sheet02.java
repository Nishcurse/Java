import java.util.Scanner;
public class Practice_Sheet02 {
    public static void main(String[] args) {
//        float a = 7/4.0f * 9/2.0f ;
//        System.out.println(a);
//        System.out.println("Welcome to Interperator!");
        Scanner sc = new Scanner(System.in);
//        System.out.println("enter the grade you wan to encrypt");
//        char grade = 'A';
//        grade = (char)(grade+8);
//        System.out.println(grade);
//        Decrypting the grade
//        grade = (char)(grade - 8);
//        System.out.println(grade);
//        System.out.println("Check  wheather the first number is grater than the second number!");
//        System.out.println("enter the first number");
//      int a = sc.nextInt();
//        System.out.println("enter the second number");
//        int b = sc.nextInt();
//        System.out.println(a>b);
//        System.out.println("If true then yes your 1 number is grater");
//        System.out.println("IF False then your 2 number is grater");i
//        int v = 7;
//        int u = 4;
//        int a = 2;
//        int s = 5;
//        float x =  v*v-u*u/(2*a*s);
    int x = 7;
        System.out.println(7.49/7 + 35/7);
    }
}
