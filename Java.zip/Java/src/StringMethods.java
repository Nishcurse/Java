import java.sql.SQLOutput;
import java.util.Scanner;

public class StringMethods {
    public static void main(String[] args) {
        String a = "Nishu";
        String as =new String("Nishkarsh");
//        System.out.println(a);
//        int  p =a.length();
//        String p =a.toUpperCase();
//        System.out.println(p);
//        String nonTrimmedString = "        NIshKarsh     ";
//        System.out.println(nonTrimmedString.trim());
//        System.out.println(a.substring(2));
//        System.out.println(a.substring(1,5));
//        System.out.println(a.replace('i','u'));
//        System.out.println(a.startsWith("Ni"));
//        System.out.println(a.endsWith("shu"));
//        System.out.println(a.charAt(0));
//        System.out.println(a.indexOf("hu"));
//        System.out.println(a.indexOf("s",3));
//        System.out.println(a.equals("Nishu"));
//        System.out.println(a.equalsIgnoreCase("NisHU"));
//        Practie Sheet #3
//        #problem 1
//        String text = "LowerCase";
//        text = text.toLowerCase();
//        System.out.println(text);
//        #Problem 2
//        String str =new String("Hari Ram");
//        System.out.println(str.replace(" ","_"));
//        Problem 3
//        Scanner sc = new Scanner(System.in);
//        String input = sc.nextLine();
//        System.out.println("Dear," +input + " Thanks a lot");
//         Problem 4
//        String aloo = "chulu  bhar    paani peelo";
//        System.out.println(aloo.indexOf("  "));
//        System.out.println(aloo.indexOf("   "));
        // Excercise 5
        String letter = " \" Dear Harry , this java course is nice \" ";
        System.out.println(letter);

    }
}
