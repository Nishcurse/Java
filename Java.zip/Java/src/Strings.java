import java.util.Scanner;
public class Strings {
    public static void main(String[] args) {
//        String name = new String("harry");
        String name = "Nishkarsh";
        System.out.print(name);
//        int a = 6 ;
//        float b = 5.867f;
//        char c  = 'a';
//        System.out.printf("The value of a is %d and the value of b is %f and the value of this is %c", a, b, c);
       Scanner sc = new Scanner(System.in);
        String st =sc.nextLine();
        System.out.println(st);
    }
}
