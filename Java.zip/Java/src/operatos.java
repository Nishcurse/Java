public class operatos {
    public static void main(String[] args) {
//        This class is all about the Java Associativity
        int a = 6*5-34/2;
        /*
        =30-34/2
        =30-17
        =13
         */
        int b = 60/5-34*2;
        /*
        =12-34*2
        =12-68
        =-56
        */
        System.out.println(a);
        System.out.println(b);
    }
}