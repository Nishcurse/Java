public class resultingDatatype {
    public static void main(String[] args) {
        // Increament and Decremeant Operators
//        int i = 56;
//        int b = 5;
//        System.out.println(i);
//        System.out.println(b);
//        System.out.println(i++);
//        System.out.println(i);
//        // i++ works from the next line
//        System.out.println(++i);
//        //while it Applies in the same line itself
//        System.out.println(i);
        int y=7;
        System.out.println(++y*8);
        char ch ='|';
        System.out.println(++ch);
    }
}
